import streamlit as st
import pandas as pd

def find_s(positive_examples):
    hypothesis = list(positive_examples.iloc[0])
    for i in range(1, len(positive_examples)):
        example = list(positive_examples.iloc[i])
        for j in range(len(hypothesis)):
            if hypothesis[j] != example[j]:
                hypothesis[j] = '?'
    return hypothesis

st.title("Find-S Algorithm for Customer Purchase Prediction")

st.write("Upload a CSV file with customer purchase history data.")
st.write("The data should contain customer attributes and a 'Purchase' column, where 'yes' indicates a positive example.")

uploaded_file = st.file_uploader("Upload your CSV file", type=["csv"])

if uploaded_file:
    df = pd.read_csv(uploaded_file)

    st.write("### Uploaded Data Preview")
    st.write(df.head())

    if 'Purchase' in df.columns:
        positive_examples = df[df['Purchase'] == 'yes'].drop(columns=['Purchase'])

        specific_hypothesis = find_s(positive_examples)
        
        st.write("### Specific Hypothesis (Find-S)")
        st.write(specific_hypothesis)
    else:
        st.error("Error: The uploaded file must contain a 'Purchase' column with values 'yes' or 'no' to indicate positive and negative examples.")
else:
    st.info("Please upload a CSV file to proceed.")
