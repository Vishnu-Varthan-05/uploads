const express = require('express');
const { createClient } = require('redis');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const port = 3000;

app.use(express.json());

const server = http.createServer(app);
const io = new Server(server);

const client = createClient({ url: 'redis://localhost:6379' });
client.connect().catch((err) => {
    console.error('Error connecting to Redis:', err);
    process.exit(1);
});

const pubsub = client.duplicate();
pubsub.connect().catch((err) => {
    console.error('Error connecting to Redis pubsub:', err);
    process.exit(1);
});

const channelName = 'notifications';

pubsub.subscribe(channelName, (message) => {
    const data = JSON.parse(message);
    io.emit('notification', data);
});

app.post('/notify', async (req, res) => {
    const { user, text } = req.body;
    if (!user || !text) {
        return res.status(400).json({ error: 'User and text are required' });
    }

    const message = JSON.stringify({ user, text });
    console.log(`Notification from ${user}: ${text}`);
    await client.publish(channelName, message);
    res.status(200).json({ success: true, message: 'Notification sent' });
});

app.get('/', (req, res) => {
    res.send(`
        <html>
            <body>
                <h2>Real-Time Notifications</h2>
                <ul id="notifications"></ul>
                <script src="/socket.io/socket.io.js"></script>
                <script>
                    const socket = io();
                    socket.on('notification', (data) => {
                        const item = document.createElement('li');
                        item.textContent = \`User: \${data.user} - Message: \${data.text}\`;
                        document.getElementById('notifications').appendChild(item);
                    });
                </script>
            </body>
        </html>
    `);
});

server.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});

process.on('SIGINT', async () => {
    await pubsub.unsubscribe(channelName);
    await client.disconnect();
    process.exit();
});
