const jwt = require("jsonwebtoken");
const User = require("./user");

const users = [
  new User(1, "vishnu", "vishnu@gmail.com", "password"),
];

const secretKey = "your-secret-key";
async function authenticateUser(email, password) {
  try {
    const user = await getUserByEmail(email);
    if (user && user.password === password) {
      const token = jwt.sign({ userId: user.id }, secretKey, { expiresIn: "1h" });
      return token;
    } else {
      throw new Error("Invalid email or password");
    }
  } catch (error) {
    throw error;
  }
}

async function getUserByEmail(email) {
  try {
    const users = await getUsers();
    const user = users.find((user) => user.email === email);
    return user;
  } catch (error) {
    throw error;
  }
}

async function createUser(id, username, email, password) {
  try {
    const user = new User(id, username, email, password);
    users.push(user);
    return user;
  } catch (error) {
    throw error;
  }
}

async function getUser(id) {
  try {
    const user = users.find((user) => user.id === parseInt(id));
    return user;
  } catch (error) {
    throw error;
  }
}

async function getUsers() {
  try {
    return users;
  } catch (error) {
    throw error;
  }
}

async function updateUser(id, username, email, password) {
  try {
    const user = users.find((user) => user.id === id);
    if (user) {
      user.username = username;
      user.email = email;
      user.password = password;
      return user;
    } else {
      throw new Error("User not found");
    }
  } catch (error) {
    throw error;
  }
}

async function deleteUser(id) {
  try {
    const index = users.findIndex((user) => user.id === id);
    if (index !== -1) {
      users.splice(index, 1);
      return true;
    } else {
      throw new Error("User not found");
    }
  } catch (error) {
    throw error;
  }
}

module.exports = {
  createUser,
  getUser,
  getUsers,
  updateUser,
  deleteUser,
  authenticateUser,
};
