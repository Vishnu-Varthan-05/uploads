const { createUser, getUser, getUsers, updateUser, deleteUser, authenticateUser } = require("./userService");

class UserController {
  async createUser(req, res) {
    try {
      const { id, username, email, password } = req.body;
      const user = await createUser(id, username, email, password);
      res.status(201).json(user);
    } catch (error) {
      res.status(500).json({ message: "Error creating user" });
    }
  }

  async getUser(req, res) {
    try {
      const id = req.params.id;
      const user = await getUser(id);
      if (user) {
        res.status(200).json(user);
      } else {
        res.status(404).json({ message: "User not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Error getting user" });
    }
  }

  async getUsers(req, res) {
    try {
      const users = await getUsers();
      res.status(200).json(users);
    } catch (error) {
      res.status(500).json({ message: "Error getting users" });
    }
  }

  async updateUser(req, res) {
    try {
      const id = req.params.id;
      const { username, email, password } = req.body;
      const user = await updateUser(id, username, email, password);
      if (user) {
        res.status(200).json(user);
      } else {
        res.status(404).json({ message: "User not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Error updating user" });
    }
  }

  async deleteUser(req, res) {
    try {
      const id = req.params.id;
      const deleted = await deleteUser(id);
      if (deleted) {
        res.status(200).json({ message: "User deleted" });
      } else {
        res.status(404).json({ message: "User not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Error deleting user" });
    }
  }
  async login(req, res) {
    try {
      const { email, password } = req.body;
      const token = await authenticateUser(email, password);
      res.json({ token });
    } catch (error) {
      res.status(401).json({ message: "Invalid email or password" });
    }
  }
}

module.exports = UserController;
