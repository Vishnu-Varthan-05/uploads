const express = require('express')
const app = express();
const port = 3000;
const cors = require('cors');
app.use(express.json());
app.use(cors());

const router = require('./routes/route')

app.use('/api', router); 

app.listen(port, ()=>{
    console.log("App is listening at port ", port);
})