const { createBlog, getBlog, getBlogs, updateBlog, deleteBlog } = require("./blogService");

class BlogController {
  async createBlog(req, res) {
    try {
      const { id, title, content, author_id } = req.body;
      const blog = await createBlog(id, title, content, author_id);
      res.status(201).json(blog);
    } catch (error) {
      res.status(500).json({ message: "Error creating blog" });
    }
  }

  async getBlog(req, res) {
    try {
      const id = req.params.id;
      const blog = await getBlog(id);
      if (blog) {
        res.status(200).json(blog);
      } else {
        res.status(404).json({ message: "Blog not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Error getting blog" });
    }
  }

  async getBlogs(req, res) {
    try {
      const blogs = await getBlogs();
      res.status(200).json(blogs);
    } catch (error) {
      res.status(500).json({ message: "Error getting blogs" });
    }
  }

  async updateBlog(req, res) {
    try {
      const id = req.params.id;
      const { title, content, author_id } = req.body;
      const blog = await updateBlog(id, title, content, author_id);
      if (blog) {
        res.status(200).json(blog);
      } else {
        res.status(404).json({ message: "Blog not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Error updating blog" });
    }
  }

  async deleteBlog(req, res) {
    try {
      const id = req.params.id;
      const deleted = await deleteBlog(id);
      if (deleted) {
        res.status(200).json({ message: "Blog deleted" });
      } else {
        res.status(404).json({ message: "Blog not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Error deleting blog" });
    }
  }
}

module.exports = BlogController;
