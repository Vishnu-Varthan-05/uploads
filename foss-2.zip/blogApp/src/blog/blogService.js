const Blog = require("./blog");
const {getUser } = require("../user/userService");

const blogs = [
  new Blog(1, "The FTC says social media companies cant be trusted to regulate themselves", "The Federal Trade Commission has released a report on the data collection policies of social media platforms and video streaming services. The report found that these platforms collect and retain large amounts of data on users and non-users, and that they cannot be trusted to regulate themselves. The report states that self-regulation has failed due to the large profits that can be made from collecting and monetizing user data.",1),
  new Blog(2, "New Study Reveals the Dark Side of Artificial Intelligence", "A recent study has shed light on the potential risks and consequences of relying too heavily on artificial intelligence. The study found that AI systems can perpetuate biases and discriminate against certain groups of people, leading to unfair outcomes and social injustices. The researchers are calling for more transparency and accountability in the development and deployment of AI systems.", 1),
  new Blog(3, "The Future of Space Exploration: What's Next for NASA?", "NASA has announced plans to return humans to the moon by 2024 and establish a sustainable presence on the lunar surface. The agency is also working towards sending humans to Mars in the 2030s. But what does the future of space exploration hold? Will we see a new era of space travel and colonization, or will we face new challenges and setbacks?", 1),
  new Blog(4, "The Impact of Climate Change on Global Food Systems", "Climate change is having a profound impact on global food systems, from crop yields to food prices. Rising temperatures and changing weather patterns are affecting the availability and quality of food, leading to food insecurity and malnutrition. What can be done to mitigate the effects of climate change on food systems and ensure a sustainable food future?", 2),
  new Blog(5, "The Rise of Virtual Reality: How VR is Changing the World", "Virtual reality technology is changing the way we live, work, and play. From gaming and entertainment to education and healthcare, VR is being used in a wide range of applications. But what are the potential risks and benefits of VR, and how will it shape our future?", 2)
];

async function createBlog(id, title, content, author_id) {
  try {
    const blog = new Blog(id, title, content, author_id);
    blogs.push(blog);
    return blog;
  } catch (error) {
    throw error;
  }
}

async function getBlog(id) {
  try {
    const blog = blogs.find((blog) => blog.id === parseInt(id));
    if (blog) {
      const user = await getUser(blog.author_id);
      blog.author = user.username;
      return blog ;
    } else {
      throw new Error("Blog not found");
    }
  } catch (error) {
    throw error;
  }
}

async function getBlogs() {
  try {
    const blogsData = blogs.map(async (blog) => {
      const user = await getUser(blog.author_id);
      blog.author = user.username;
      return blog ;
    });
    return Promise.all(blogsData);
  } catch (error) {
    throw error;
  }
}



async function updateBlog(id, title, content, author_id) {
  try {
    const blog = blogs.find((blog) => blog.id === id);
    if (blog) {
      blog.title = title;
      blog.content = content;
      blog.author_id = author_id;
      return blog;
    } else {
      throw new Error("Blog not found");
    }
  } catch (error) {
    throw error;
  }
}

async function deleteBlog(id) {
  try {
    const index = blogs.findIndex((blog) => blog.id === id);
    if (index !== -1) {
      blogs.splice(index, 1);
      return true;
    } else {
      throw new Error("Blog not found");
    }
  } catch (error) {
    throw error;
  }
}

module.exports = {
  createBlog,
  getBlog,
  getBlogs,
  updateBlog,
  deleteBlog,
};
