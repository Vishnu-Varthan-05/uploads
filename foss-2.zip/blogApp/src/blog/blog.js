class Blog {
    id;
    title;
    content;
    author_id;

    constructor(id, title, content, author_id) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.author_id = author_id;
    }
}

module.exports = Blog;
