const express = require("express");
const router = express.Router();

const authenticateMiddleware = require("../middleware/authenticateMiddleware");
const UserController = require("../user/userController");
const BlogController = require("../blog/blogController");

const userController =  new UserController
const blogController =  new BlogController

router.post("/users/login", userController.login)
router.post("/users", userController.createUser);


router.use(authenticateMiddleware);

router.get("/users/:id", userController.getUser);
router.get("/users", userController.getUsers);
router.put("/users/:id", userController.updateUser);
router.delete("/users/:id", userController.deleteUser);


router.post("/blogs", blogController.createBlog);
router.get("/blogs/:id", blogController.getBlog);
router.get("/blogs", blogController.getBlogs);
router.put("/blogs/:id", blogController.updateBlog);
router.delete("/blogs/:id", blogController.deleteBlog);

module.exports = router;
