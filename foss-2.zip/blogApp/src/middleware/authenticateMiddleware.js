const jwt = require("jsonwebtoken");
const { getUser} = require("../user/userService");

const authenticateMiddleware = async (req, res, next) => {
  try {
    const token = req.header("Authorization").replace("Bearer ", "");
    const decoded = jwt.verify(token, "your-secret-key");
    const user = await getUser(decoded.userId);
    if (user) {
      req.user = user;
      next();
    } else {
      throw new Error("Invalid token");
    }
  } catch (error) {
    res.status(401).json({ message: "Unauthorized" });
  }
};

module.exports = authenticateMiddleware;
