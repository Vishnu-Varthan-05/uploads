import socket
import threading

def receive_messages(client_socket):
    while True:
        try:
            message, server = client_socket.recvfrom(1024)
            print(message.decode('utf-8'))
        except:
            print("Error receiving message.")
            break

client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
client_socket.connect(("127.0.0.1", 5555))

print("Connected to the chat server. Start typing your messages!")

receive_thread = threading.Thread(target=receive_messages, args=(client_socket,))
receive_thread.start()

while True:
    message = input("")
    client_socket.sendto(message.encode('utf-8'), ("127.0.0.1", 5555))
