import socket
import threading

# Server addresses
TCP_HOST = '127.0.0.1'
TCP_PORT = 12345
UDP_HOST = '127.0.0.1'
UDP_PORT = 12346

# Set up TCP server
tcp_server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
tcp_server.bind((TCP_HOST, TCP_PORT))
tcp_server.listen(5)

# Set up UDP server
udp_server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
udp_server.bind((UDP_HOST, UDP_PORT))

# Function to handle TCP messages
def handle_tcp(client_socket):
    while True:
        try:
            message = client_socket.recv(1024).decode()
            if message == 'EXIT':
                print("Connection closed.")
                break
            print(f"TCP message received: {message}")
        except Exception as e:
            print(f"Error in TCP communication: {e}")
            break
    client_socket.close()

# Function to handle UDP messages
def handle_udp():
    while True:
        try:
            message, addr = udp_server.recvfrom(1024)
            message = message.decode()
            print(f"UDP message received: The user is {message}....")
        except Exception as e:
            print(f"Error in UDP communication: {e}")

# Start TCP server thread
def start_tcp_server():
    while True:
        client_socket, addr = tcp_server.accept()
        print(f"New connection from {addr}")
        threading.Thread(target=handle_tcp, args=(client_socket,)).start()

# Start UDP server thread
def start_udp_server():
    threading.Thread(target=handle_udp).start()

if __name__ == "__main__":
    # Start the TCP server and UDP server
    threading.Thread(target=start_tcp_server).start()
    start_udp_server()
