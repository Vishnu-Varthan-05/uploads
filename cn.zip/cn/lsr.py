import heapq

class Graph:
    def __init__(self):
        self.adjacency_list = {}
    
    def add_router(self, name):
        if name not in self.adjacency_list:
            self.adjacency_list[name] = {}
    
    def add_link(self, router1, router2, cost):
        self.adjacency_list[router1][router2] = cost
        self.adjacency_list[router2][router1] = cost
    
    def link_state_routing(self, start):
        distances = {router: float('inf') for router in self.adjacency_list}
        distances[start] = 0
        priority_queue = [(0, start)]
        predecessors = {start: None}
        
        while priority_queue:
            current_distance, current_router = heapq.heappop(priority_queue)
            
            if current_distance > distances[current_router]:
                continue
            
            for neighbor, weight in self.adjacency_list[current_router].items():
                distance = current_distance + weight
                
                if distance < distances[neighbor]:
                    distances[neighbor] = distance
                    predecessors[neighbor] = current_router
                    heapq.heappush(priority_queue, (distance, neighbor))
        
        return distances, predecessors

# Creating the graph
network = Graph()
network.add_router("A")
network.add_router("B")
network.add_router("C")
network.add_router("D")

# Adding links with costs
network.add_link("A", "B", 1)
network.add_link("A", "C", 4)
network.add_link("B", "C", 2)
network.add_link("B", "D", 5)
network.add_link("C", "D", 1)

# Running LSR for each router
for router in network.adjacency_list:
    distances, predecessors = network.link_state_routing(router)
    print(f"Shortest paths from router {router}:")
    for dest, dist in distances.items():
        path = []
        step = dest
        while step is not None:
            path.append(step)
            step = predecessors.get(step)
        path = path[::-1]
        print(f"To {dest}: {' -> '.join(path)} with cost {dist}")
    print()
