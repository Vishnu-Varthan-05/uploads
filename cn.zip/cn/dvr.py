class Router:
    def __init__(self, name):
        self.name = name
        self.neighbors = {}
        self.distance_vector = {}
        self.routing_table = {}
        
    def add_neighbor(self, neighbor, cost):
        self.neighbors[neighbor] = cost
        self.distance_vector[neighbor.name] = cost
        self.routing_table[neighbor.name] = (neighbor, cost)
    
    def update_distance_vector(self):
        changed = False
        for neighbor, cost in self.neighbors.items():
            for dest, dest_cost in neighbor.distance_vector.items():
                new_cost = cost + dest_cost
                if dest not in self.distance_vector or new_cost < self.distance_vector[dest]:
                    self.distance_vector[dest] = new_cost
                    self.routing_table[dest] = (neighbor, new_cost)
                    changed = True
        return changed

def distance_vector_routing(routers):
    converged = False
    while not converged:
        converged = True
        for router in routers:
            if router.update_distance_vector():
                converged = False

# Creating routers
A = Router("A")
B = Router("B")
C = Router("C")
D = Router("D")

# Connecting routers with link costs
A.add_neighbor(B, 1)
A.add_neighbor(C, 4)
B.add_neighbor(C, 2)
B.add_neighbor(D, 5)
C.add_neighbor(D, 1)

# Initializing and running DVR
routers = [A, B, C, D]
distance_vector_routing(routers)

# Displaying routing tables
for router in routers:
    print(f"Routing Table for {router.name}:")
    for dest, (next_hop, cost) in router.routing_table.items():
        print(f"To {dest} via {next_hop.name} with cost {cost}")
    print()
