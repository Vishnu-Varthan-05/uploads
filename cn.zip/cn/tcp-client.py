import socket
import threading

def receive_messages(client_socket):
    while True:
        try:
            message = client_socket.recv(1024).decode('utf-8')
            if message:
                print(message)
            else:
                print("Disconnected from server.")
                break
        except:
            print("Error in receiving message. Disconnected from server.")
            break

    client_socket.close()

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
    client_socket.connect(("127.0.0.1", 5555))
    print("Connected to the chat server. Start typing your messages!")
except:
    print("Unable to connect to the server.")
    exit()

receive_thread = threading.Thread(target=receive_messages, args=(client_socket,))
receive_thread.start()

while True:
    try:
        message = input()
        if message.lower() == 'exit':
            client_socket.close()
            print("Disconnected from the chat.")
            break
        client_socket.send(message.encode('utf-8'))
    except:
        print("Error in sending message.")
        client_socket.c
