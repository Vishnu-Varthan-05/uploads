import socket

server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_socket.bind(("0.0.0.0", 5555))
print("[STARTED] UDP chat server started on port 5555")

clients = set()

while True:
    message, client_address = server_socket.recvfrom(1024)
    print(f"[{client_address}] {message.decode('utf-8')}")
    
    if client_address not in clients:
        clients.add(client_address)

    for client in clients:
        if client != client_address:
            server_socket.sendto(message, client)
