import socket
import threading

# Server address
TCP_HOST = '127.0.0.1'
TCP_PORT = 12345
UDP_HOST = '127.0.0.1'
UDP_PORT = 12346

# Set up TCP client
tcp_client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
tcp_client.connect((TCP_HOST, TCP_PORT))

# Set up UDP client
udp_client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Function to handle sending messages via TCP
def send_tcp_message(message):
    tcp_client.send(message.encode())

# Function to handle sending "TYPING" messages via UDP
def send_udp_message(message):
    udp_client.sendto(message.encode(), (UDP_HOST, UDP_PORT))

# Function to receive messages (TCP)
def receive_tcp_messages():
    while True:
        try:
            message = tcp_client.recv(1024).decode()
            print(f"Received (TCP): {message}")
        except Exception as e:
            print(f"Error in receiving TCP message: {e}")
            break

# Function to send messages
def send_messages():
    while True:
        message = input("Enter message: ")

        if message.upper() == "TYPING":
            send_udp_message("TYPING")
        else:
            send_tcp_message(message)

if __name__ == "__main__":
    # Start thread to receive TCP messages
    threading.Thread(target=receive_tcp_messages).start()

    # Start sending messages
    send_messages()
