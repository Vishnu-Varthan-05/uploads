import binascii

def load_file_bytes(file_path):
    with open(file_path, 'rb') as file:
        file_bytes = file.read()
    return file_bytes

def calculate_crc(file_bytes):
    return binascii.crc32(file_bytes) & 0xFFFFFFFF

def verify_crc(file_bytes, received_crc):
    calculated_crc = calculate_crc(file_bytes)
    return calculated_crc == received_crc

def calculate_checksum(file_bytes):
    checksum = 0
    for byte in file_bytes:
        checksum = (checksum + byte) % 256
    return checksum

def verify_checksum(file_bytes, received_checksum):
    calculated_checksum = calculate_checksum(file_bytes)
    return calculated_checksum == received_checksum

def main(file_path):
    print(f"Calculating CRC and Checksum for file: {file_path}")
    
    file_bytes = load_file_bytes(file_path)
    
    original_crc = calculate_crc(file_bytes)
    original_checksum = calculate_checksum(file_bytes)
    
    print(f"Original CRC32: {original_crc}")
    print(f"Original Checksum: {original_checksum}")
    
    print("\nVerifying after transfer...\n")
    crc_valid = verify_crc(file_bytes, original_crc)
    checksum_valid = verify_checksum(file_bytes, original_checksum)
    
    print("CRC Verification:", "Passed" if crc_valid else "Failed")
    print("Checksum Verification:", "Passed" if checksum_valid else "Failed")

file_path = "example.txt"  
main(file_path)
