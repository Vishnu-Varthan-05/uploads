import streamlit as st
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn.metrics import silhouette_score, davies_bouldin_score
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

# Load and preprocess data
data = pd.read_csv('data.csv')
data = data.dropna()

scaler = StandardScaler()
scaled_data = scaler.fit_transform(data)

# Set the number of clusters directly (no sidebar)
n_clusters = 3  # or any fixed number you prefer

# K-Means Clustering
kmeans = KMeans(n_clusters=n_clusters, random_state=42)
kmeans_labels = kmeans.fit_predict(scaled_data)
kmeans_silhouette = silhouette_score(scaled_data, kmeans_labels)
kmeans_davies_bouldin = davies_bouldin_score(scaled_data, kmeans_labels)

# EM/Gaussian Mixture Clustering
em = GaussianMixture(n_components=n_clusters, random_state=42)
em_labels = em.fit_predict(scaled_data)
em_silhouette = silhouette_score(scaled_data, em_labels)
em_davies_bouldin = davies_bouldin_score(scaled_data, em_labels)

# Display metrics
st.write(f"### K-Means Clustering (n_clusters={n_clusters})")
st.write(f"Silhouette Score: {kmeans_silhouette:.2f}")
st.write(f"Davies-Bouldin Index: {kmeans_davies_bouldin:.2f}")
st.write("Cluster Centers:")
st.write(kmeans.cluster_centers_)

st.write(f"### Gaussian Mixture Clustering (n_components={n_clusters})")
st.write(f"Silhouette Score: {em_silhouette:.2f}")
st.write(f"Davies-Bouldin Index: {em_davies_bouldin:.2f}")
st.write("Means:")
st.write(em.means_)

# Plot the clustered data
fig, ax = plt.subplots(1, 2, figsize=(12, 6))

# K-Means Plot
ax[0].scatter(scaled_data[:, 0], scaled_data[:, 1], c=kmeans_labels, cmap='viridis', marker='o', s=30)
ax[0].scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], s=200, c='red', label='Centers')
ax[0].set_title("K-Means Clustering")
ax[0].legend()

# Gaussian Mixture Plot
ax[1].scatter(scaled_data[:, 0], scaled_data[:, 1], c=em_labels, cmap='viridis', marker='o', s=30)
ax[1].scatter(em.means_[:, 0], em.means_[:, 1], s=200, c='blue', label='Means')
ax[1].set_title("Gaussian Mixture Clustering")
ax[1].legend()

st.pyplot(fig)
